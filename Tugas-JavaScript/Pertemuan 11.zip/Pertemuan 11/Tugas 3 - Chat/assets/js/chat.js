function kirimChat(){
    let isiChat = document.getElementById("chatbox").value
    let Chat = document.getElementById("chat")
    Chat.innerHTML = isiChat
}